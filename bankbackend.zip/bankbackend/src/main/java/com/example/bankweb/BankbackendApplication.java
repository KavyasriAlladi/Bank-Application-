package com.example.bankweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankbackendApplication.class, args);
	}

}
