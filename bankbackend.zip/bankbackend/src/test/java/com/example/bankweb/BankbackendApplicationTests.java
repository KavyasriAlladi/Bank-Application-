package com.example.bankweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
